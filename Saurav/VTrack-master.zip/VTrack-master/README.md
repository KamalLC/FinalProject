# VTrack
Vehicle Tracking System Using YOLO

# Architecture

# Project Setup Instructions

clone the repo<br/>
`git clone git@https://github.com/PrasannaDangol/VTrack.git`<br/><br/>
Install dependencies<br/>
`pip install -r requirements.txt`<br/><br/>
Execute project in development mode<br/>
`python manage.py runserver`<br/><br/>
Browse the project<br/>
`http:\\localhost:{PORT}`<br/><br/>



