# .gitignore should include reference to config.py
api = "d556ce08038dc557212064b77c813638-cb3791c4-86a51140"
domain = "https://api.mailgun.net/v3/sandboxdf77ccd81df84593a6631b92722baf1e.mailgun.org/messages"