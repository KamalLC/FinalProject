from django.contrib import admin
from .models import MissingVehicle
# Register your models here.
admin.site.register(MissingVehicle)