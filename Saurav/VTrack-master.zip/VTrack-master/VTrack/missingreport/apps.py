from django.apps import AppConfig


class MissingreportConfig(AppConfig):
    name = 'missingreport'
